#!/bin/bash

# stop tomcat service
sudo service tomcat7 stop
