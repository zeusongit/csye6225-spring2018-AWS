#!/bin/bash

# update the permission and ownership of WAR file in the tomcat webapps directory
