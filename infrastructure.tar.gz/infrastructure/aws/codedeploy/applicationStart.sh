#!/bin/bash
sudo service tomcat7 start
