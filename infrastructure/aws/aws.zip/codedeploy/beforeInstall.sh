#!/bin/bash

# change to tomcat webapps directory.
# this directory will be different for different tomcat versions.
cd /var/webapp
sudo rm -rf *
