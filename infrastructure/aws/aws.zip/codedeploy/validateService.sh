#!/bin/bash

# You may skip validation for now.